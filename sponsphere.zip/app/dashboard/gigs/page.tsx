import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Search } from "lucide-react"

export default function GigsPage() {
  const gigs = [
    {
      id: "1",
      title: "Lifestyle Product Review",
      description:
        "Looking for a lifestyle influencer to review our new eco-friendly home products. Must have at least 10k followers.",
      budget: "$500",
      status: "open",
      tags: ["lifestyle", "review", "product"],
      date: "2 days ago",
      matchScore: 95,
    },
    {
      id: "2",
      title: "Fashion Instagram Post",
      description:
        "Need a fashion influencer for a sponsored post featuring our summer collection. Looking for creative photography.",
      budget: "$300",
      status: "open",
      tags: ["fashion", "instagram", "photography"],
      date: "3 days ago",
      matchScore: 87,
    },
    {
      id: "3",
      title: "Tech Unboxing Video",
      description:
        "Seeking tech YouTuber for an unboxing video of our new smartphone. Must have experience with tech reviews.",
      budget: "$750",
      status: "open",
      tags: ["tech", "youtube", "unboxing"],
      date: "5 days ago",
      matchScore: 82,
    },
    {
      id: "4",
      title: "Fitness Workout Routine",
      description:
        "Looking for fitness influencer to create a workout routine using our equipment. Must have certified training background.",
      budget: "$600",
      status: "open",
      tags: ["fitness", "workout", "health"],
      date: "1 week ago",
      matchScore: 78,
    },
    {
      id: "5",
      title: "Cooking Recipe Video",
      description:
        "Need a food content creator to showcase recipes using our kitchen appliances. Must have cooking experience.",
      budget: "$450",
      status: "open",
      tags: ["cooking", "food", "recipe"],
      date: "1 week ago",
      matchScore: 75,
    },
  ]

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Gigs</h2>
          <p className="text-muted-foreground">Browse and find gigs that match your interests</p>
        </div>
        <Link href="/dashboard/gigs/create">
          <Button>Create New Gig</Button>
        </Link>
      </div>

      <div className="flex flex-col gap-4 md:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input type="search" placeholder="Search gigs..." className="w-full pl-8" />
        </div>
        <Button variant="outline">Filter</Button>
      </div>

      <div className="space-y-4">
        {gigs.map((gig) => (
          <Card key={gig.id}>
            <CardContent className="p-6">
              <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-lg">{gig.title}</h3>
                    <Badge variant={gig.status === "open" ? "default" : "secondary"}>{gig.status}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{gig.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {gig.tags.map((tag) => (
                      <div
                        key={tag}
                        className="rounded-full bg-secondary px-2.5 py-0.5 text-xs text-secondary-foreground"
                      >
                        #{tag}
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="font-medium">Budget: {gig.budget}</span>
                    <span className="text-muted-foreground">Posted {gig.date}</span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">Match Score:</span>
                    <Badge variant="outline" className="bg-primary/10 text-primary">
                      {gig.matchScore}%
                    </Badge>
                  </div>
                  <Link href={`/dashboard/gigs/${gig.id}`}>
                    <Button>View Details</Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

